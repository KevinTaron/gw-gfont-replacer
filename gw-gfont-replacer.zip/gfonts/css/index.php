<?php
//Silence is golden.