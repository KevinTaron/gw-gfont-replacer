# gw-gfont-replacer
Wordpress Plugin to replace Google Fonts with local Font files
